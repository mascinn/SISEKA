---
name: Institutional Islamic FinTech
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#404942'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#707971'
  outline-variant: '#c0c9c0'
  surface-tint: '#2d6a48'
  primary: '#003820'
  on-primary: '#ffffff'
  primary-container: '#0f5132'
  on-primary-container: '#84c39b'
  inverse-primary: '#95d4ac'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#00334d'
  on-tertiary: '#ffffff'
  tertiary-container: '#004b6d'
  on-tertiary-container: '#51beff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b0f1c7'
  primary-fixed-dim: '#95d4ac'
  on-primary-fixed: '#002111'
  on-primary-fixed-variant: '#0f5132'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  financial-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  financial-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-margin: 24px
  gutter: 16px
  card-padding: 20px
  section-gap: 40px
---

## Brand & Style
The design system embodies a "Clean Islamic Modern" aesthetic, blending the precision of global financial institutions with the heritage of Islamic art. It targets a demographic that values ethical finance, security, and clarity.

The visual style is characterized by **Corporate Modernism** with a **Minimalist** ethos. It avoids ornamental excess, instead focusing on high-quality typography, intentional whitespace, and a "Secure-First" atmosphere. The emotional response should be one of profound trust, stability, and institutional permanence. Surfaces are clean, layouts are structured, and interactions are deliberate rather than playful.

## Colors
This design system utilizes a palette rooted in **Deep Emerald Green**, symbolizing growth and Islamic heritage, paired with **Warm Gold** to denote value and excellence. 

- **Primary:** Deep Emerald is used for core navigation, primary actions, and branding headers.
- **Secondary:** Warm Gold is reserved for high-priority accents, certifications, and active selection states.
- **Surface Strategy:** The primary background is white, but `surface_mint` is used for content containers (cards) to provide a soft, fresh distinction from the page background.
- **Functional Colors:** Sky Blue is used for surplus or positive balance indicators, distinct from the Success Emerald used for completed transactions.

## Typography
Typography is split into two functional roles. **Plus Jakarta Sans** provides a modern, approachable, and friendly voice for all interface labels, headlines, and body copy. 

For all monetary values and balance sheets, **Inter** is utilized with `tabular-nums` enabled. This ensures that financial figures align perfectly in columns, facilitating easy scanning and comparison. 

- **Weighting:** Use Bold (700) for primary balances and Semibold (600) for secondary metadata.
- **Scale:** Maintain high contrast between headlines and body text to enforce a clear information hierarchy.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid** model. On desktop, content is centered within a 1280px max-width container using a 12-column grid. On mobile, the system transitions to a single-column fluid layout with 20px side margins.

- **Rhythm:** An 8px linear scale is used for structural spacing, while a 4px scale is used for internal component padding.
- **Financial Grids:** Data tables should use a compact vertical rhythm (12px padding) to maximize information density while maintaining legibility through high horizontal gutters.

## Elevation & Depth
This design system uses a **Low-Contrast Tonal** approach to depth. Instead of heavy shadows, hierarchy is established through surface color changes and subtle borders.

- **Inner Borders:** All cards and containers utilize a 1px solid border in `border_subtle` (#F1F5F9).
- **Surface Stacking:** The background is a very light gray (#F8FAFC). Interactive cards use white (#FFFFFF) or `surface_mint` (#ECFDF5).
- **Modals:** Bottom-sheets on mobile use a soft 20% opacity black backdrop blur to focus user attention, appearing to "slide up" from the bottom edge rather than floating.

## Shapes
The shape language is defined by **rounded-2xl** (1rem / 16px) for major components. This softens the "institutional" feel, making the application feel modern and accessible.

- **Containers:** Large cards and modals use 16px (rounded-2xl).
- **Interactive Elements:** Buttons and input fields use 12px (rounded-xl) for a slightly more precise appearance.
- **Selection Indicators:** Small badges or chips use full pill-rounding (9999px).

## Components
- **Buttons:** Primary buttons are solid Deep Emerald (#0F5132) with white text. Secondary buttons use a ghost style with an Emerald border or a Gold text link for specific financial actions.
- **Financial Cards:** Use the `surface_mint` background. They must feature a subtle `border-slate-100` and display the "Financial-xl" typography for the main balance.
- **Bottom-Sheet Modals:** These are the primary container for mobile actions. They feature a 4px wide "grabber" bar at the top center and 24px top-corner rounding.
- **Floating Action Bars:** Placed at the bottom of the viewport on mobile, these house the primary navigation or "Quick Transaction" triggers. They should have a high-blur backdrop and a 1px top border.
- **Input Fields:** Use a white background with a Slate Gray text color. The focus state is a 2px Deep Emerald ring with no offset.
- **Status Chips:** Use low-saturation background tints of the status colors (Success, Alert, Danger) with high-saturation text of the same hue for maximum accessibility.